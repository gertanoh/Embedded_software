# KTH_Embedded_Systems
Labcode and such for the course
