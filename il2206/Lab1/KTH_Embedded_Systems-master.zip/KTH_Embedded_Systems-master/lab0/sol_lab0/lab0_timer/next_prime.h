#ifndef NEXT_PRIME_H_
#define NEXT_PRIME_H_

int next_prime( int inval );

#endif /*NEXT_PRIME_H_*/
